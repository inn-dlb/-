package com.example.youownme;

import java.io.Serializable;

//此类的实例为一条具体的随礼记录
public class OutBean implements Serializable {
    private String year;
    private String month;
    private String day;
    private String name;
    private String money;
    private String reason;

    //初始化类
    public OutBean(String year,String month,String day,String name,String money,String reason){
        this.year = year;
        this.month = month;
        this.day = day;
        this.name = name;
        this.money = money;
        this.reason = reason;
    }

    //获取数据
    public String getYear() {
        return year;
    }
    public String getMonth() {
        return month;
    }
    public String getDay() {
        return day;
    }
    public String getName() {
        return name;
    }
    public String getMoney() {
        return money;
    }
    public String getReason(){ return reason;}

    //设置/修改数据
    public void setYear(String year) {
        this.year = year;
    }
    public void setMonth(String month) {
        this.month = month;
    }
    public void setDay(String day) {
        this.day = day;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setMoney(String money) {
        this.money = money;
    }
    public void setReason(String reason){ this.reason = reason;}
}

