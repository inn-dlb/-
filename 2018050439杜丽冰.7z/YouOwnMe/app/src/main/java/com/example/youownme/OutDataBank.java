package com.example.youownme;

import android.content.Context;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class OutDataBank {
    private Context context;
    private final String OUT_FILE_NAME="out.txt";
    //此数组为随礼记录的集合
    private ArrayList<OutBean> arrayListOfOutDatas = new ArrayList<>();
    //获取随礼记录
    public ArrayList<OutBean> getBeans() {
        return arrayListOfOutDatas;
    }
    public OutDataBank(Context context) {
        this.context=context;
    }

    public void Save()
    {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(context.openFileOutput(OUT_FILE_NAME,Context.MODE_PRIVATE));
            oos.writeObject(arrayListOfOutDatas);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void Load()
    {
        ObjectInputStream ois = null;
        arrayListOfOutDatas = new ArrayList<>();
        try {
            ois = new ObjectInputStream(context.openFileInput(OUT_FILE_NAME));
            arrayListOfOutDatas = (ArrayList<OutBean>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
