package com.example.youownme;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import static android.app.Activity.RESULT_OK;

public class MoneyInFragment extends Fragment {
    private InDataBank inDatas;
    private OutDataBank outDatas;
    private MainActivity.InAdapter inAdapter;
    private MainActivity.OutAdapter outAdapter;
    private static final int CONTEXT_MENU_ITEM_NEW = 1;
    private static final int CONTEXT_MENU_ITEM_UPDATE = CONTEXT_MENU_ITEM_NEW+1;
    private static final int CONTEXT_MENU_ITEM_DELETE = CONTEXT_MENU_ITEM_UPDATE+1;
    private static final int REQUEST_CODE_ADD = 100;
    private static final int REQUEST_CODE_UPDATE = 101;

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        int position=data.getIntExtra("position",0);
        String year=data.getStringExtra("year");
        String month=data.getStringExtra("month");
        String day=data.getStringExtra("day");
        String name=data.getStringExtra("name");
        String money=data.getStringExtra("money");
        String reason=data.getStringExtra("reason");
        int selected=data.getIntExtra("selected",0);

        switch (requestCode) {
            case REQUEST_CODE_ADD:
                if (resultCode == RESULT_OK) {
                    switch (selected){
                        case 1:
                            outDatas.getBeans().add(new OutBean(year, month, day, name, money, reason));
                            outDatas.Save();
                            outAdapter.notifyDataSetChanged();
                            break;
                        case 2:
                            inDatas.getBeans().add(position, new InBean(year, month, day, name, money, reason));
                            inDatas.Save();
                            inAdapter.notifyDataSetChanged();
                            break;
                    }
                }
                break;
            case REQUEST_CODE_UPDATE:
                if (resultCode == RESULT_OK) {
                    switch (selected){
                        case 1:
                            outDatas.getBeans().add(new OutBean(year,month,day,name,money,reason));
                            outDatas.Save();
                            outAdapter.notifyDataSetChanged();
                            inDatas.getBeans().remove(position);
                            inDatas.Save();
                            inAdapter.notifyDataSetChanged();
                            break;
                        case 2:
                            inDatas.getBeans().get(position).setYear(year);
                            inDatas.getBeans().get(position).setMonth(month);
                            inDatas.getBeans().get(position).setDay(day);
                            inDatas.getBeans().get(position).setName(name);
                            inDatas.getBeans().get(position).setMoney(money);
                            inDatas.getBeans().get(position).setReason(reason);
                            inDatas.Save();
                            inAdapter.notifyDataSetChanged();
                            break;
                    }
                }
                break;
            default:
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if(v==this.getActivity().findViewById(R.id.inList)) {
            menu.setHeaderTitle("操作");
            menu.add(1, CONTEXT_MENU_ITEM_NEW, 1, "新增");
            menu.add(1, CONTEXT_MENU_ITEM_UPDATE, 1, "修改");
            menu.add(1, CONTEXT_MENU_ITEM_DELETE, 1, "删除");
        }
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Intent intent;
        final int position=menuInfo.position;
        switch(item.getItemId())
        {
            case CONTEXT_MENU_ITEM_NEW:
                intent = new Intent(this.getContext(), InputActivity.class);
                intent.putExtra("way","fragment");
                intent.putExtra("selected",2);
                intent.putExtra("position",position+1);
                intent.putExtra("selected_year",new MainFragment().selected_year);
                intent.putExtra("selected_month",new MainFragment().selected_month);
                intent.putExtra("selected_day",new MainFragment().selected_day);
                startActivityForResult(intent, REQUEST_CODE_ADD);
                break;

            case CONTEXT_MENU_ITEM_UPDATE:
                intent = new Intent(this.getContext(), InputActivity.class);
                intent.putExtra("way","fragment");
                intent.putExtra("selected",2);
                intent.putExtra("position",position);
                intent.putExtra("old_year", inDatas.getBeans().get(position).getYear());
                intent.putExtra("old_month", inDatas.getBeans().get(position).getMonth());
                intent.putExtra("old_day", inDatas.getBeans().get(position).getDay());
                intent.putExtra("old_name", inDatas.getBeans().get(position).getName());
                intent.putExtra("old_money", inDatas.getBeans().get(position).getMoney());
                intent.putExtra("old_reason", inDatas.getBeans().get(position).getReason());
                startActivityForResult(intent, REQUEST_CODE_UPDATE);
                break;

            case CONTEXT_MENU_ITEM_DELETE:
                AlertDialog.Builder builder = new AlertDialog.Builder(this.getContext());
//                builder.setTitle("询问");
                builder.setMessage("你确定要删除?");
                builder.setCancelable(true);
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        inDatas.getBeans().remove(position);
                        inDatas.Save();
                        inAdapter.notifyDataSetChanged();
                    }
                });  //正面的按钮（肯定）
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }); //反面的按钮（否定)
                builder.create().show();
                break;
            default:
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_money_in, container, false);
        View v1=inflater.inflate(R.layout.fragment_money_out,container,false);
        initData();
        initView(v,v1);
        return v;
    }

    private void initView(View v,View v1){
        outAdapter = new MainActivity.OutAdapter(this.getContext(), R.layout.items_lists,outDatas.getBeans());
        ListView outList=v1.findViewById(R.id.outList);
        outList.setAdapter(outAdapter);
        inAdapter = new MainActivity.InAdapter(this.getContext(),R.layout.items_lists,inDatas.getBeans());
        ListView inList=v.findViewById(R.id.inList);
        inList.setAdapter(inAdapter);
        //注册菜单
        this.registerForContextMenu(inList);
    }
    private void initData(){
        inDatas = new InDataBank(this.getContext());
        inDatas.Load();
        outDatas = new OutDataBank(this.getContext());
        outDatas.Load();
    }


    public MoneyInFragment() {}
    public static MoneyInFragment newInstance(String param1, String param2) {
        MoneyInFragment fragment = new MoneyInFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}