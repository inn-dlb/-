package com.example.youownme;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        setContentView(R.layout.activity_splash);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);//隐藏状态栏
        //隐藏标题栏
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Thread splashThread=new Thread(){//创建子线程
            @Override
            public void run() {
                try{
                    sleep(2000);
                    Intent intent=new Intent(getApplicationContext(),MainActivity.class);//启动MainActivity
                    startActivity(intent);
                    finish();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        splashThread.start();//启动线程
    }
}