package com.example.youownme;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class InputActivity extends AppCompatActivity {

    private EditText edit_year,edit_month,edit_day, edit_name, edit_reason, edit_money;
    private RadioButton radioButton1, radioButton2;
    private RadioGroup radioGroup;
    private Button ok_button;   //提交键
    private String year,month,day,name,money,reason,selected_year,selected_month,selected_day,way;
    private int position,selected;
    private int iyear,imonth,iday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        //隐藏标题栏
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        //初始化组件
        initView();
        //初始化数据
        initData();
        //判断并提交新建数据
        initListener();
    }

    private void initView() {
        edit_year = (EditText) findViewById(R.id.edit_year);
        edit_month = (EditText) findViewById(R.id.edit_month);
        edit_day = (EditText) findViewById(R.id.edit_day);
        edit_name = (EditText) findViewById(R.id.edit_name);
        edit_money = (EditText) findViewById(R.id.edit_money);
        edit_reason = (EditText) findViewById(R.id.edit_reason);
        radioButton1 = (RadioButton) findViewById(R.id.radioButton1);
        radioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        ok_button = (Button) findViewById(R.id.ok_button);
    }
    private void initData() {
        position = getIntent().getIntExtra("position",0);
        selected = getIntent().getIntExtra("selected",0);
        selected_year = getIntent().getStringExtra("selected_year");
        selected_month = getIntent().getStringExtra("selected_month");
        selected_day = getIntent().getStringExtra("selected_day");
        year =getIntent().getStringExtra("old_year");
        month =getIntent().getStringExtra("old_month");
        day =getIntent().getStringExtra("old_day");
        name =getIntent().getStringExtra("old_name");
        money =getIntent().getStringExtra("old_money");
        reason =getIntent().getStringExtra("old_reason");
        way = getIntent().getStringExtra("way");
        //设置默认
        if(1==selected){
            radioButton1.setChecked(true);
        }
        else if(2==selected){
            radioButton2.setChecked(true);
        }
        if(null!= year) {
            edit_year.setText(year);
        }else if(null!=selected_year){
            edit_year.setText(selected_year);
        }
        if(null!= month) {
            edit_month.setText(month);
        }else if(null!=selected_month){
            edit_month.setText(selected_month);
        }
        if(null!= day) {
            edit_day.setText(day);
        }else if(null!=selected_day){
            edit_day.setText(selected_day);
        }

        if(null!= name)
            edit_name.setText(name);
        if(null!= money)
            edit_money.setText(money);
        if(null!= reason)
            edit_reason.setText(reason);
    }
    private void initListener() {
        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                year = edit_year.getText().toString();
                month = edit_month.getText().toString();
                day = edit_day.getText().toString();
                name = edit_name.getText().toString();
                money = edit_money.getText().toString();
                reason = edit_reason.getText().toString();
                iyear = Integer.parseInt(year);
                imonth = Integer.parseInt(month);
                iday = Integer.parseInt(day);
                selected = radioGroup.getCheckedRadioButtonId();

                //判断输入是否合规
                if (iyear>=1970 && iyear<=2100 && imonth>=1 && imonth<=12 && iday>=1 && iday<=31 && name.length()>0 && money.length()>0 && reason.length()>0) {
                    if(way.equals("addButton")){
                        Intent intent = new Intent(InputActivity.this, MainActivity.class);
                        intent.putExtra("position",position);
                        intent.putExtra("year", year);
                        intent.putExtra("month", month);
                        intent.putExtra("day", day);
                        intent.putExtra("name", name);
                        intent.putExtra("money", money);
                        intent.putExtra("reason", reason);
                        if(selected==R.id.radioButton1){
                            intent.putExtra("selected",1);
                            startActivity(intent);
                        }
                        else if(selected==R.id.radioButton2){
                            intent.putExtra("selected",2);
                            startActivity(intent);
                        }
                    }
                    else if(way.equals("fragment")){
                        Intent intent = new Intent();
                        //传入数据
                        intent.putExtra("position",position);
                        intent.putExtra("year", year);
                        intent.putExtra("month", month);
                        intent.putExtra("day", day);
                        intent.putExtra("name", name);
                        intent.putExtra("money", money);
                        intent.putExtra("reason", reason);

                        if(selected==R.id.radioButton1){
                            intent.putExtra("selected",1);
                            setResult(RESULT_OK,intent);
                            finish();
                        }
                        else if(selected==R.id.radioButton2){
                            intent.putExtra("selected",2);
                            setResult(RESULT_OK,intent);
                            finish();
                        }
                    }
                }
                else
                {
                    Toast.makeText(v.getContext(),"请填写完整或填写正确！",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}