package com.example.youownme;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private FragmentManager fgManager;
    private RelativeLayout reLay;
    private FloatingActionButton addButton;
    private ImageView mainButton,inButton,outButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //隐藏标题栏
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //初始化组件并显示mainfragment
        initView();
        fgManager=getSupportFragmentManager();
        FragmentTransaction transaction = fgManager.beginTransaction();
        transaction.replace(R.id.reLay, new MainFragment());
        transaction.commit();
        //监听
        initListener();
        //对新建记录的处理
        result();
    }
    private void initView(){
        mainButton = (ImageView)findViewById(R.id.mainButton);
        outButton = (ImageView)findViewById(R.id.outButton);
        inButton = (ImageView)findViewById(R.id.inButton);
        addButton = (FloatingActionButton)findViewById(R.id.addButton);
        reLay = (RelativeLayout)findViewById(R.id.reLay);
    }
    private void initListener(){
        mainButton.setOnClickListener(this);
        inButton.setOnClickListener(this);
        outButton.setOnClickListener(this);
        addButton.setOnClickListener(this);
    }
    public void onClick(View v){
        Intent intent;
        switch (v.getId()){
            case R.id.outButton: {
                FragmentTransaction transaction = fgManager.beginTransaction();
                transaction.replace(R.id.reLay, new MoneyOutFragment());
                transaction.commit();
                break;
            }

            case R.id.mainButton: {
                FragmentTransaction transaction = fgManager.beginTransaction();
                transaction.replace(R.id.reLay, new MainFragment());
                transaction.commit();
                break;
            }

            case R.id.inButton: {
                FragmentTransaction transaction = fgManager.beginTransaction();
                transaction.replace(R.id.reLay, new MoneyInFragment());
                transaction.commit();
                break;
            }

            case R.id.addButton: {
                intent = new Intent(MainActivity.this, InputActivity.class);
                //默认日历选中的日期
                intent.putExtra("way","addButton");
                intent.putExtra("selected_year",new MainFragment().selected_year);
                intent.putExtra("selected_month",new MainFragment().selected_month);
                intent.putExtra("selected_day",new MainFragment().selected_day);
                startActivity(intent);
                break;
            }
        }
    }
    public void result() {
        //获取新建记录后返回的数据
        Intent it = getIntent();
        String year = it.getStringExtra("year");
        String month = it.getStringExtra("month");
        String day = it.getStringExtra("day");
        String name = it.getStringExtra("name");
        String money = it.getStringExtra("money");
        String reason = it.getStringExtra("reason");
        int selected = it.getIntExtra("selected", 0);

        //判断属于随礼还是收礼
        if (selected == 1) {    //随礼
            OutDataBank outDatas = new OutDataBank(this);
            outDatas.Load();
            //添加随礼记录
            outDatas.getBeans().add(new OutBean(year, month, day, name, money, reason));
            outDatas.Save();
        }
        else if (selected == 2) {    //收礼
            InDataBank inDatas = new InDataBank(this);
            inDatas.Load();
            //添加收礼记录
            inDatas.getBeans().add(new InBean(year, month, day, name, money, reason));
            inDatas.Save();
        }
    }
    public static class InAdapter extends ArrayAdapter<InBean> {
        private int resourceId;
        public InAdapter(@NonNull Context context, int resource, @NonNull List<InBean> objects) {
            super(context, resource,objects);
            this.resourceId=resource;
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            InBean inBean = getItem(position);//获取当前项的实例
            View view;
            if(null==convertView)
                view = LayoutInflater.from(getContext()).inflate(this.resourceId, parent, false);
            else
                view=convertView;
            ((TextView) view.findViewById(R.id.text_name)).setText(inBean.getName());
            ((TextView) view.findViewById(R.id.text_reason)).setText(inBean.getReason());
            ((TextView) view.findViewById(R.id.text_money)).setText(inBean.getMoney()+"元");
            ((TextView) view.findViewById(R.id.text_date)).setText(inBean.getYear()+"/"+inBean.getMonth()+"/"+inBean.getDay());
            ((TextView) view.findViewById(R.id.little_icon)).setText(">");
            return view;
        }
    }
    public static class OutAdapter extends ArrayAdapter<OutBean> {
        private int resourceId;
        public OutAdapter(@NonNull Context context, int resource, @NonNull List<OutBean> objects) {
            super(context, resource,objects);
            this.resourceId=resource;
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            OutBean outBean = getItem(position);//获取当前项的实例
            View view;
            if(null==convertView)
                view = LayoutInflater.from(getContext()).inflate(this.resourceId, parent, false);
            else
                view=convertView;
            ((TextView) view.findViewById(R.id.text_name)).setText(outBean.getName());
            ((TextView) view.findViewById(R.id.text_reason)).setText(outBean.getReason());
            ((TextView) view.findViewById(R.id.text_money)).setText(outBean.getMoney()+"元");
            ((TextView) view.findViewById(R.id.text_date)).setText(outBean.getYear()+"/"+outBean.getMonth()+"/"+outBean.getDay());
            ((TextView) view.findViewById(R.id.little_icon)).setText(">");
            return view;
        }
    }
}