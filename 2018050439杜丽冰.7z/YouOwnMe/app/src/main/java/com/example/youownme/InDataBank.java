package com.example.youownme;

import android.content.Context;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class InDataBank {
    private Context context;
    private final String IN_FILE_NAME="in.txt";
    //此数组为收礼记录的集合
    private ArrayList<InBean> arrayListOfInDatas = new ArrayList<>();;
    //获取收礼记录
    public ArrayList<InBean> getBeans() {
        return arrayListOfInDatas;
    }
    public InDataBank(Context context) { this.context=context;}

    public void Save()
    {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(context.openFileOutput(IN_FILE_NAME,Context.MODE_PRIVATE));
            oos.writeObject(arrayListOfInDatas);
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void Load()
    {
        ObjectInputStream ois = null;
        arrayListOfInDatas = new ArrayList<>();
        try {
            ois = new ObjectInputStream(context.openFileInput(IN_FILE_NAME));
            arrayListOfInDatas = (ArrayList<InBean>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
