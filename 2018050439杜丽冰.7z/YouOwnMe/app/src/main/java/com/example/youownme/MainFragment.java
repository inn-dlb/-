package com.example.youownme;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainFragment extends Fragment {

    public CalendarView calendarView;
    //当前日期或被选中的日期
    public Calendar now_time;
    public static String selected_year;
    public static String selected_month;
    public static String selected_day;
    //显示下方列表所需的变量
    private OutDataBank outDatas;
    private InDataBank inDatas;
    private ArrayList<OutBean> outBeansOfThatDay;
    private ArrayList<InBean> inBeansOfThatDay;
    private ArrayList<OutBean> outBeans;
    private ArrayList<InBean> inBeans;
    private ThatDayInAdapter thatDayInAdapter;
    private ThatDayOutAdapter thatDayOutAdapter;
    private ListView outList;
    private ListView inList;

    public MainFragment() {
        // Required empty public constructor
    }

//    public static MainFragment newInstance(String param1, String param2) {
//        MainFragment fragment = new MainFragment();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, param1);
//        args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
//        return fragment;
//    }

//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
////        if (getArguments() != null) {
////            mParam1 = getArguments().getString(ARG_PARAM1);
////            mParam2 = getArguments().getString(ARG_PARAM2);
////        }
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        initTime(view);
        return view;
    }
    private void initTime(View view){
        calendarView = (CalendarView)view.findViewById(R.id.calendarView);
        //默认当天时间
        Calendar ca = Calendar.getInstance();
        selected_year = Integer.toString(ca.get(Calendar.YEAR));
        selected_month = Integer.toString(ca.get(Calendar.MONTH)+1);
        selected_day = Integer.toString(ca.get(Calendar.DAY_OF_MONTH));
        //显示随礼收礼列表
        showTheLists(view);

        //选择日期
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                selected_year = Integer.toString(year);
                selected_month = Integer.toString(month+1);
                selected_day = Integer.toString(dayOfMonth);
                //更改随礼收礼的数组、适配器，重新显示
                onDateChangeTheLists();
            }
        });
    }
    private void showTheLists(View view){
        //获取随礼记录
        outDatas=new OutDataBank(this.getContext());
        outDatas.Load();
        outBeans = new ArrayList<>(outDatas.getBeans());
        outBeansOfThatDay = new ArrayList<>();
        //将每条记录的日期与时间对比
        for(int i=0;i<outBeans.size();i++){
            if(outBeans.get(i).getYear().equals(selected_year) &&
                    outBeans.get(i).getMonth().equals(selected_month)
                    && outBeans.get(i).getDay().equals(selected_day))
            {
                outBeansOfThatDay.add(outBeans.get(i));
            }
        }
        //显示当天的随礼记录
        thatDayOutAdapter = new ThatDayOutAdapter(this.getContext(),
                R.layout.that_day_lists,outBeansOfThatDay);
        outList=view.findViewById(R.id.thatDayOutList);
        outList.setAdapter(thatDayOutAdapter);

        //获取收礼记录
        inDatas=new InDataBank(this.getContext());
        inDatas.Load();
        inBeans = new ArrayList<>(inDatas.getBeans());
        inBeansOfThatDay = new ArrayList<>();
        //将每条记录的日期与时间对比
        for(int i=0;i<inBeans.size();i++){
            if(inBeans.get(i).getYear().equals(selected_year) && inBeans.get(i).getMonth().equals(selected_month)
                    && inBeans.get(i).getDay().equals(selected_day))
            {
                inBeansOfThatDay.add(inBeans.get(i));
            }
        }
        //显示当天的收礼记录
        thatDayInAdapter = new ThatDayInAdapter(this.getContext(), R.layout.that_day_lists,inBeansOfThatDay);
        inList=view.findViewById(R.id.thatDayInList);
        inList.setAdapter(thatDayInAdapter);
    }
    //当日期改变后更改下方显示列表的相应数据
    private void onDateChangeTheLists(){
        outBeansOfThatDay = new ArrayList<>();
        for(int i=0;i<outBeans.size();i++){
            if(outBeans.get(i).getYear().equals(selected_year) && outBeans.get(i).getMonth().equals(selected_month)
                    && outBeans.get(i).getDay().equals(selected_day))
            {
                outBeansOfThatDay.add(outBeans.get(i));
            }
        }
        thatDayOutAdapter = new ThatDayOutAdapter(getContext(), R.layout.that_day_lists,outBeansOfThatDay);
        outList.setAdapter(thatDayOutAdapter);

        inBeansOfThatDay = new ArrayList<>();
        for(int i=0;i<inBeans.size();i++){
            if(inBeans.get(i).getYear().equals(selected_year) && inBeans.get(i).getMonth().equals(selected_month)
                    && inBeans.get(i).getDay().equals(selected_day))
            {
                inBeansOfThatDay.add(inBeans.get(i));
            }
        }
        thatDayInAdapter = new ThatDayInAdapter(getContext(), R.layout.that_day_lists,inBeansOfThatDay);
        inList.setAdapter(thatDayInAdapter);
    }

    private class ThatDayOutAdapter extends ArrayAdapter<OutBean> {
        private int resourceId;
        public ThatDayOutAdapter(@NonNull Context context, int resource, @NonNull List<OutBean> objects) {
            super(context, resource,objects);
            this.resourceId=resource;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            OutBean outBean = getItem(position);//获取当前项的实例
            View view;
            if(null==convertView)
                view = LayoutInflater.from(getContext()).inflate(this.resourceId, parent, false);
            else
                view=convertView;
            ((TextView) view.findViewById(R.id.out_in)).setText("随礼");
            ((TextView) view.findViewById(R.id.that_name)).setText(outBean.getName());
            ((TextView) view.findViewById(R.id.that_reason)).setText(outBean.getReason());
            ((TextView) view.findViewById(R.id.that_money)).setText(outBean.getMoney()+"元");
//            ((TextView) view.findViewById(R.id.little_icon)).setText(">");
            return view;
        }
    }
    private class ThatDayInAdapter extends ArrayAdapter<InBean> {
        private int resourceId;
        public ThatDayInAdapter(@NonNull Context context, int resource, @NonNull List<InBean> objects) {
            super(context, resource,objects);
            this.resourceId=resource;
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            InBean inBean = getItem(position);//获取当前项的实例
            View view;
            if(null==convertView)
                view = LayoutInflater.from(getContext()).inflate(this.resourceId, parent, false);
            else
                view=convertView;
            ((TextView) view.findViewById(R.id.out_in)).setText("收礼");
            ((TextView) view.findViewById(R.id.that_name)).setText(inBean.getName());
            ((TextView) view.findViewById(R.id.that_reason)).setText(inBean.getReason());
            ((TextView) view.findViewById(R.id.that_money)).setText(inBean.getMoney()+"元");
            return view;
        }
    }
}